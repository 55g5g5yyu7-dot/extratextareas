Ext.onReady(function() {
    MODx.load({ xtype: 'extratextareas-panel-home', renderTo: 'extratextareas-panel-home-div' });
});
