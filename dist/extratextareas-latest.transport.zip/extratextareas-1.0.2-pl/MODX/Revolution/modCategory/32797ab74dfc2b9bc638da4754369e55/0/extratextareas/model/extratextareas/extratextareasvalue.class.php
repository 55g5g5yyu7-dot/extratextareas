<?php

class ExtraTextAreasValue extends xPDO\Om\xPDOSimpleObject
{
}
