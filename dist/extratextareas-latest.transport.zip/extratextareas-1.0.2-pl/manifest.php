<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GPLv2+',
    'readme' => '# ExtraTextAreas for MODX 3.1+

Компонент добавляет дополнительные текстовые области на вкладку редактирования ресурса и хранит значения в отдельных таблицах.

## Возможности

- Управление списком дополнительных полей в разделе **Компоненты → ExtraTextAreas**.
- Автоматическая подгрузка активных полей на вкладку контента ресурса.
- Сохранение контента и выбранного редактора для каждого дополнительного поля.
- Авто-обнаружение доступных редакторов по активным плагинам системы (Ace/CKEditor/Tiny и т.п.).
- Установка через стандартный MODX **Установщик** (`*.transport.zip`).

## Ручная сборка стандартными средствами PHP (без SSH/exec/composer)

Добавлен скрипт `php _build/build.manual.php`, который запускает `build.transport.php` **в текущем PHP-процессе**.

Что нужно:
- рабочий установленный MODX (чтобы существовал `config.core.php`)
- сам репозиторий компонента

Скрипт сам пытается найти MODX:
- сначала в корне репозитория,
- затем в родительской папке (типичный случай `/public_html/extratextareas-main`),
- либо можно явно указать путь через `MODX_BASE_PATH`.

Пример запуска:

```bash
MODX_BASE_PATH=/полный/путь/к/modx php _build/build.manual.php
```

Результат:
- пакет создаётся в `core/packages/` вашего MODX.

## Важно про установку

Установщик MODX не ставит «сырой» git-репозиторий. Нужен собранный архив вида:

- `extratextareas-<version>-<release>.transport.zip`

## Локальная сборка (если когда-нибудь появится доступ к CLI)

### 1) Репозиторий в корне MODX

```bash
php _build/build.transport.php
```

### 2) Репозиторий в отдельной папке

```bash
MODX_BASE_PATH=/path/to/modx php _build/build.transport.php
```

Скрипт проверяет наличие `config.core.php` и валидирует необходимые файлы перед упаковкой.


## Локальная сборка через браузер (без SSH/CLI)

Если у вас только FTP/файловый доступ, можно запускать сборку через веб-скрипт:

1. Распакуйте репозиторий в файловую систему сервера.
2. Откройте в браузере: `https://ваш-сайт/_build/build.web.php`
   - (совместимость) также можно открыть: `https://ваш-сайт/_build/build_web.php`
3. Скрипт автоматически пытается найти `config.core.php` в корне репозитория и в родительской папке (удобно для структуры вида `/public_html/extratextareas-main`).
4. Если MODX расположен в другой директории, передайте параметр:
   - `https://ваш-сайт/_build/build.web.php?modx_base_path=/полный/путь/к/modx/`
5. Скрипт запускает `build.transport.php` напрямую в текущем PHP-процессе (без `proc_open`/`exec`).
6. Готовый пакет ищите в `core/packages/` вашего MODX.
7. Внизу страницы есть блок «Отчёт для пересылки» — можно скопировать его целиком для диагностики ошибок.

> ⚠️ Рекомендация по безопасности: после сборки удалите `/_build/build.web.php` с сервера или ограничьте доступ к нему (например, по IP/basic-auth), чтобы никто посторонний не запускал сборку.

## Что устанавливается пакетом

- Namespace `extratextareas`.
- CMP (меню и action `home`).
- Плагин `ExtraTextAreas` (`OnDocFormRender`, `OnDocFormSave`).
- Файлы из `core/components/extratextareas/` и `assets/components/extratextareas/`.
- Таблицы `extratextareas_fields` и `extratextareas_values` (через resolver).

## Ограничение текущей версии

Выбор редактора для каждого поля сохраняется в БД. Для жёсткой привязки конкретного editor API к каждому textarea может потребоваться дополнительная интеграция с конкретными редакторными дополнениями.
',
    'changelog' => '1.0.2-pl
- Build script hardening and clearer installer workflow.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '25947501f52505e42baf3370331730a3',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modNamespace/c01c02ba2525c451da1754e24772fc61.vehicle',
      'namespace' => 'extratextareas',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'b883a9bc1a148ac7d67e5ab4f7d5c736',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modNamespace/f6eede8f587bf77937404ac1ec9fea21.vehicle',
      'namespace' => 'extratextareas',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'b1771aeed5b52b4fb64986df5204f770',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/5cee9cd89c501de0b8c15acb1423675f.vehicle',
      'namespace' => 'extratextareas',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '685822547fa493ccc8b93b8434a16606',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modMenu/b02665bf66db0520a79f682eaeb4bd45.vehicle',
      'namespace' => 'extratextareas',
    ),
  ),
);