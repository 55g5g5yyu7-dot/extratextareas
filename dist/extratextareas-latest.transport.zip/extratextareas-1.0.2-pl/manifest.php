<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GPLv2+',
    'readme' => '# ExtraTextAreas for MODX 3.1+

Компонент добавляет дополнительные текстовые области на вкладку редактирования ресурса и хранит значения в отдельных таблицах.

## Возможности

- Управление списком дополнительных полей в разделе **Компоненты → ExtraTextAreas**.
- Автоматическая подгрузка активных полей на вкладку контента ресурса.
- Сохранение контента и выбранного редактора для каждого дополнительного поля.
- Авто-обнаружение доступных редакторов по активным плагинам системы (Ace/CKEditor/Tiny и т.п.).
- Установка через стандартный MODX **Установщик** (`*.transport.zip`).

## Ручная сборка стандартными средствами PHP (без SSH/exec/composer)

Добавлен скрипт `php _build/build.manual.php`, который запускает `build.transport.php` **в текущем PHP-процессе**.

Что нужно:
- рабочий установленный MODX (чтобы существовал `config.core.php`)
- сам репозиторий компонента

Скрипт сам пытается найти MODX:
- сначала в корне репозитория,
- затем в родительской папке (типичный случай `/public_html/extratextareas-main`),
- либо можно явно указать путь через `MODX_BASE_PATH`.

Пример запуска:

```bash
MODX_BASE_PATH=/полный/путь/к/modx php _build/build.manual.php
```

Результат:
- пакет создаётся в `core/packages/` вашего MODX.

## Важно про установку

Установщик MODX не ставит «сырой» git-репозиторий. Нужен собранный архив вида:

- `extratextareas-<version>-<release>.transport.zip`

## Локальная сборка (если когда-нибудь появится доступ к CLI)

### 1) Репозиторий в корне MODX

```bash
php _build/build.transport.php
```

### 2) Репозиторий в отдельной папке

```bash
MODX_BASE_PATH=/path/to/modx php _build/build.transport.php
```

Скрипт проверяет наличие `config.core.php` и валидирует необходимые файлы перед упаковкой.


## Локальная сборка через браузер (без SSH/CLI)

Если у вас только FTP/файловый доступ, можно запускать сборку через веб-скрипт:

1. Распакуйте репозиторий в файловую систему сервера.
2. Откройте в браузере: `https://ваш-сайт/_build/build.web.php`
   - (совместимость) также можно открыть: `https://ваш-сайт/_build/build_web.php`
3. Скрипт автоматически пытается найти `config.core.php` в корне репозитория и в родительской папке (удобно для структуры вида `/public_html/extratextareas-main`).
4. Если MODX расположен в другой директории, передайте параметр:
   - `https://ваш-сайт/_build/build.web.php?modx_base_path=/полный/путь/к/modx/`
5. Скрипт запускает `build.transport.php` напрямую в текущем PHP-процессе (без `proc_open`/`exec`).
6. Готовый пакет ищите в `core/packages/` вашего MODX.
7. Внизу страницы есть блок «Отчёт для пересылки» — можно скопировать его целиком для диагностики ошибок.

> ⚠️ Рекомендация по безопасности: после сборки удалите `/_build/build.web.php` с сервера или ограничьте доступ к нему (например, по IP/basic-auth), чтобы никто посторонний не запускал сборку.

## Что устанавливается пакетом

- Namespace `extratextareas`.
- CMP (меню и action `home`).
- Плагин `ExtraTextAreas` (`OnDocFormRender`, `OnDocFormSave`).
- Файлы из `core/components/extratextareas/` и `assets/components/extratextareas/`.
- Таблицы `extratextareas_fields` и `extratextareas_values` (через resolver).

## Ограничение текущей версии

Выбор редактора для каждого поля сохраняется в БД. Для жёсткой привязки конкретного editor API к каждому textarea может потребоваться дополнительная интеграция с конкретными редакторными дополнениями.
',
    'changelog' => '1.0.2-pl
- Build script hardening and clearer installer workflow.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '7f5fe8e4cb2379a68f3cedca075a297a',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modNamespace/325a47c06842c6ed3bc312e7670e5b03.vehicle',
      'namespace' => 'extratextareas',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '0487b0b980917720506955fa807c8efb',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modNamespace/851e08bbe83d96ce0d06630032580920.vehicle',
      'namespace' => 'extratextareas',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'a237f3143565d12f7646e227fad4d595',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/e8d2bf66f0c68f28b4be3cc7a1528cd5.vehicle',
      'namespace' => 'extratextareas',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'b443464a8f19dcf3ee1ef1fbe3b495f0',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modMenu/727dcf186dc579fa48a624a214e46789.vehicle',
      'namespace' => 'extratextareas',
    ),
  ),
);