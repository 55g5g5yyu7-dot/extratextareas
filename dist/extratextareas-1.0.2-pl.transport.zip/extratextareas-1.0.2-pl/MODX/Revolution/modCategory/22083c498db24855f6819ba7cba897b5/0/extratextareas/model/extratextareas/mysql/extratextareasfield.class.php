<?php

require_once dirname(__DIR__) . '/extratextareasfield.class.php';

class ExtraTextAreasField_mysql extends ExtraTextAreasField
{
}
