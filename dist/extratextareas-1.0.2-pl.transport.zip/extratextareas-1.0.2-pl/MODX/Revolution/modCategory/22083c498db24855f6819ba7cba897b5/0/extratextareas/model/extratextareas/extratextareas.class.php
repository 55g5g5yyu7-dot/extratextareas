<?php

class ExtraTextAreas extends xPDO\Om\xPDOSimpleObject
{
}
