<?php

require_once dirname(__DIR__) . '/extratextareasvalue.class.php';

class ExtraTextAreasValue_mysql extends ExtraTextAreasValue
{
}
