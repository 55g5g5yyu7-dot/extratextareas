<?php

class ExtraTextAreasField extends xPDO\Om\xPDOSimpleObject
{
}
