<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GPLv2+',
    'readme' => '# ExtraTextAreas for MODX 3.1+

Компонент добавляет дополнительные текстовые области на вкладку редактирования ресурса и хранит значения в отдельных таблицах.

## Возможности

- Управление списком дополнительных полей в разделе **Компоненты → ExtraTextAreas**.
- Автоматическая подгрузка активных полей на вкладку контента ресурса.
- Сохранение контента и выбранного редактора для каждого дополнительного поля.
- Авто-обнаружение доступных редакторов по активным плагинам системы (Ace/CKEditor/Tiny и т.п.).
- Установка через стандартный MODX **Установщик** (`*.transport.zip`).

## Ручная сборка стандартными средствами PHP (без SSH/exec/composer)

Добавлен скрипт `php _build/build.manual.php`, который запускает `build.transport.php` **в текущем PHP-процессе**.

Что нужно:
- рабочий установленный MODX (чтобы существовал `config.core.php`)
- сам репозиторий компонента

Скрипт сам пытается найти MODX:
- сначала в корне репозитория,
- затем в родительской папке (типичный случай `/public_html/extratextareas-main`),
- либо можно явно указать путь через `MODX_BASE_PATH`.

Пример запуска:

```bash
MODX_BASE_PATH=/полный/путь/к/modx php _build/build.manual.php
```

Результат:
- пакет создаётся в `core/packages/` вашего MODX.

## Важно про установку

Установщик MODX не ставит «сырой» git-репозиторий. Нужен собранный архив вида:

- `extratextareas-<version>-<release>.transport.zip`

## Локальная сборка (если когда-нибудь появится доступ к CLI)

### 1) Репозиторий в корне MODX

```bash
php _build/build.transport.php
```

### 2) Репозиторий в отдельной папке

```bash
MODX_BASE_PATH=/path/to/modx php _build/build.transport.php
```

Скрипт проверяет наличие `config.core.php` и валидирует необходимые файлы перед упаковкой.


## Локальная сборка через браузер (без SSH/CLI)

Если у вас только FTP/файловый доступ, можно запускать сборку через веб-скрипт:

1. Распакуйте репозиторий в файловую систему сервера.
2. Откройте в браузере: `https://ваш-сайт/_build/build.web.php`
   - (совместимость) также можно открыть: `https://ваш-сайт/_build/build_web.php`
3. Скрипт автоматически пытается найти `config.core.php` в корне репозитория и в родительской папке (удобно для структуры вида `/public_html/extratextareas-main`).
4. Если MODX расположен в другой директории, передайте параметр:
   - `https://ваш-сайт/_build/build.web.php?modx_base_path=/полный/путь/к/modx/`
5. Скрипт запускает `build.transport.php` напрямую в текущем PHP-процессе (без `proc_open`/`exec`).
6. Готовый пакет ищите в `core/packages/` вашего MODX.
7. Внизу страницы есть блок «Отчёт для пересылки» — можно скопировать его целиком для диагностики ошибок.

> ⚠️ Рекомендация по безопасности: после сборки удалите `/_build/build.web.php` с сервера или ограничьте доступ к нему (например, по IP/basic-auth), чтобы никто посторонний не запускал сборку.

## Что устанавливается пакетом

- Namespace `extratextareas`.
- CMP (меню и action `home`).
- Плагин `ExtraTextAreas` (`OnDocFormRender`, `OnDocFormSave`).
- Файлы из `core/components/extratextareas/` и `assets/components/extratextareas/`.
- Таблицы `extratextareas_fields` и `extratextareas_values` (через resolver).

## Ограничение текущей версии

Выбор редактора для каждого поля сохраняется в БД. Для жёсткой привязки конкретного editor API к каждому textarea может потребоваться дополнительная интеграция с конкретными редакторными дополнениями.
',
    'changelog' => '1.0.2-pl
- Build script hardening and clearer installer workflow.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '2d89b787ec7d38728f22d51e2f7c40f1',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modNamespace/ea6713dc941da6d14d681fa5c67cc940.vehicle',
      'namespace' => 'extratextareas',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'ef9b7ab791b2a40a2f9cc80f2b8095a8',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modNamespace/9238d697bce8a9c45cca292e481d51a4.vehicle',
      'namespace' => 'extratextareas',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '22c5e41bc22514d2f07849f7e11dee76',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/3f2460e46a91ee2a4e15aca7f39d56ea.vehicle',
      'namespace' => 'extratextareas',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'd54c5fb45f47cf1b40b19d0c1da75857',
      'native_key' => 'extratextareas',
      'filename' => 'MODX/Revolution/modMenu/6982d817d07bc3bbe8e666615d8ed96f.vehicle',
      'namespace' => 'extratextareas',
    ),
  ),
);